package com.stackroute.collections;

import java.util.ArrayList;
import java.util.List;

/*
 * This class contains methods for adding Fruits to a List and searching the fruits from the List
 */
public class FruitsListService {
	
    public static List<String> addFruitsToList(String fruitNames) {
    	List<String> list = new ArrayList<String>();
    	if(fruitNames == null || fruitNames.isEmpty()) {
    		return list;
    	}
    	String[] arr = fruitNames.split(",");
    	for (String string : arr) {
    		int flag = 0;
			for (String string2 : list) {
				if(string.compareToIgnoreCase(string2) == 0)
					flag = 1;
			}
			if(flag == 1)
				continue;
    		else {
				list.add(string);
			}
		}
        return list;
    }

    public static int searchFruitInList(List<String> fruitList, String searchFruit) {
    	for (String string : fruitList) {
			if(string.compareTo(searchFruit) == 0)
				return fruitList.indexOf(string);
		}
    	for (String string : fruitList) {
			if(string.compareToIgnoreCase(searchFruit) == 0)
				return -1;
		}
    	
    	return -1;
    }

    public static int searchFruitInListIgnoreCase(List<String> fruitList, String searchFruit) {
    	for (String string : fruitList) {
			if(string.compareToIgnoreCase(searchFruit) == 0)
				return fruitList.indexOf(string);
		}
    	return -1;
    }
}