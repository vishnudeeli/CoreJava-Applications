package com.stackroute.collections;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class WordsReverseTests {
    private WordsReverse wordsReverse;
    private static final String MESSAGE = "Check the logic of your reverseWordsOfString method";
    private static final String PROPER_MESSAGE = "Give proper string input";
    private static final String PROPER_NULL_MESSAGE = "Give proper input string not null";

    @BeforeEach
    public void setUp() {
        wordsReverse = new WordsReverse();
    }

    @AfterEach
    public void tearDown() {
        wordsReverse = null;
    }

    @Test
    public void givenInputStringWithWordsThenReturnResult()  {
        String input = "Java Programming";
        String output = "avaJ gnimmargorP";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenInputStringWithoutWhiteSpaceThenReturnResult()  {
        String input = "Coding";
        String output = "gnidoC";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenInputStringWithSpecialCharactersThenReturnResult()  {
        String input = "^@%#$^$!@^#$ #@*&%$*!#&^$*&@ *#^*^$(@*^$(*#(@* @$^!%#$^!@#&!%";
        String output = "$#^@!$^$#%@^ @&*$^&#!*$%&*@# *@(#*($^*@($^*^#* %!&#@!^$#%!^$@";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenInputStringWithNumbersThenReturnResult(){
        String input = "328947298 30940913240340979 8934798163841298 8329842934094343444";
        String output = "892749823 97904304231904903 8921483618974398 4443434904392489238";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenInputStringWithTailingSpacesThenReturnResult() {
        String input = "Java Programming Coding ";
        String output = "avaJ gnimmargorP gnidoC ";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenInputStringWithLeadingSpacesThenReturnResult() {
        String input = " Junit Testing";
        String output = " tinuJ gnitseT";
        assertEquals(output, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenEmptyInputThenReturnErrorString()  {
        String input = "";
        assertEquals(PROPER_MESSAGE, wordsReverse.reverseWordsOfString(input), MESSAGE);
    }

    @Test
    public void givenNullThenReturnErrorString() {
        assertEquals(PROPER_NULL_MESSAGE, wordsReverse.reverseWordsOfString(null), MESSAGE);
    }
}
