package com.stackroute.collections;

import java.util.Stack;

public class WordsReverse {
    //write logic to find reverse the words of the string using Stack
    public String reverseWordsOfString(String input)  {
    	if(input == null) 
    		return "Give proper input string not null";
    	if(input.isEmpty())
    		return "Give proper string input";
    	
    	String[] string = input.split(" ");
    	
    	Stack<Character> stack = new Stack<Character>();
    	String output = "";
    	for (String str : string) {
			char[] chArray = str.toCharArray();
			for (char ch : chArray) {
				stack.push(ch);
			}
			while(!stack.isEmpty()) {
				output = output + stack.pop();
			}
			output = output + " ";	
		}
    	if(input.charAt(input.length()-1) != ' ') {
    		output = output + "]";
    		output = output.replace(" ]", "");
    	}
        return output;
    }
}
