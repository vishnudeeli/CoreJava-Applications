package com.stackroute.collections;

import java.time.LocalDate;
import java.util.*;

/*
This class contains a property called movieMap of type Map
This class contains methods for adding key-value pairs of Movie and its rating to HashMap and
various methods for accessing the keys and values based on some conditions
 */
public class MovieService {

    /**
     * Constructor to create movieMap as an empty  LinkedHashMap object
     */
    public MovieService() {
    }

    /*
    Returns the movieMap object
     */
    Map<Movie , Integer> movieMap = new LinkedHashMap<Movie,Integer>();
    public Map<Movie, Integer> getMovieMap() {
        return movieMap;
    }

    /*
    Add key-value pairs of Movie-Integer type and returns Set of Map.Entry
     */
    public Set<Map.Entry<Movie, Integer>> addKeyValuePairsToMap(Movie movie, Integer rating) {
    	movieMap.put(movie, rating);
    	Set<Map.Entry<Movie , Integer>> entrySet = movieMap.entrySet();
        return entrySet;
    }

    /*
    Return Set of movie names having rating greater than or equal to given rating
     */
    public List<String> getHigherRatedMovieNames(int rating) {
    	List<String> li = new ArrayList<String>();
    	for (Map.Entry<Movie, Integer> entry : movieMap.entrySet()) {
    		if(entry.getValue() >= rating) {
    			li.add(entry.getKey().getMovieName());
    		}
           
        }
    	if(li.isEmpty()) {
    		List<String>li1 = Collections.emptyList();
    		return li1;
    	}
        return li;
    }

    /*
    Return Set of movie names belonging to specific genre
     */
    public List<String> getMovieNamesOfSpecificGenre(String genre) {
    	List<String> li = new ArrayList<String>();
    	for (Map.Entry<Movie, Integer> entry : movieMap.entrySet()) {
    		if(entry.getKey().getGenre().equals(genre)) {
    			//Movie m1 = new Movie();
    			li.add(entry.getKey().getMovieName());
    		}
           
        }
    	if(li.isEmpty()) {
    		List<String>li1 = Collections.emptyList();
    		return li1;
    	}
        return li;
    }

   /*
   Return Set of movie names which are released after Specific releaseDate and having rating less than or equal to 3
    */

    public List<String> getMovieNamesReleasedAfterSpecificDateAndRatingLesserThanThree(LocalDate releaseDate) {
    	List<String> li = new ArrayList<String>();
    	for (Map.Entry<Movie, Integer> entry : movieMap.entrySet() ) {
    		if(entry.getKey().getReleaseDate().isAfter(releaseDate)	&& entry.getValue() <= 3) {
    			//Movie m1 = new Movie();
    			li.add(entry.getKey().getMovieName());
    		}
           
        }
    	if(li.isEmpty()) {
    		List<String>li1 = Collections.emptyList();
    		return li1;
    	}
        return li;
    }

    /*
    Return set of movies sorted by release dates in ascending order.
    Hint: Use TreeMap
     */
    public List<Movie> getSortedMovieListByReleaseDate() {
    	List<Movie> li = new ArrayList<Movie>();
   	 Map<Movie,Integer>sorted = new TreeMap<Movie,Integer>();
        for (Map.Entry<Movie, Integer> entry : movieMap.entrySet()) {
     		if(sorted.containsKey(entry.getKey())) {
     			
     		}
     		else {
     			sorted.put(entry.getKey(),entry.getValue());
     			li.add(entry.getKey());
     		}
            
         }
        Collections.sort(li);
       return li;
   }
    

    /*
   Return set of movies sorted by rating.
   Hint: Use Comparator and LinkedHashMap
    */
    public Map<Movie, Integer> getSortedMovieListByRating() {
    	//Set <Map.Entry<Movie, Integer>> set = new LinkedHashSet<Map.Entry<Movie, Integer>>();
   	 Map<Movie,Integer>sorted = new TreeMap<Movie,Integer>();
       for (Map.Entry<Movie, Integer> entry : movieMap.entrySet()) {
    		if(sorted.containsKey(entry.getKey())) {
    			
    		}
    		else {
    			sorted.put(entry.getKey(),entry.getValue());
    		}
           
        }
       return sorted;
    }
}


