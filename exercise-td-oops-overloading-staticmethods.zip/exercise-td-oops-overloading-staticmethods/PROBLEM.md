## Problem Statement - Utility Static Methods

This exercise should be completed using Test Driven Development Technique.

  - Test class provided in this exercise will show compilation errors, when the exercise is cloned locally
  - Classes and methods should be created by analysing the test code, so that there are no compilation errors
  - Functionality of methods should be completed, so that all the test cases pass 
  - Some of the business requirements are mentioned below

- This problem contains creation of static methods and overloading the static methods

**Method fahrenheitToCelcius**
        
      Formula for converting farhenheit to celcius
       
      [celcius = (farhenheit - 32) X 5 / 9]
      
      Celcius returned as int should be rounded to nearest integer
      Overloading should be used for converting input fahrenheit in double


**Method getLevel**

    - Should return level based on the sum of all input array elements as per below rules
        HIGH    -  sum is greater than or equal to 100, 
        MEDIUM  -  sum is greater than or equal to 70
        LOW     -  sum is less than 70



## Instructions
- Take care of whitespace/trailing whitespace
- Do not change the provided class/method names unless instructed
- Ensure your code compiles without any errors/warning/deprecations 
- Follow best practices while coding