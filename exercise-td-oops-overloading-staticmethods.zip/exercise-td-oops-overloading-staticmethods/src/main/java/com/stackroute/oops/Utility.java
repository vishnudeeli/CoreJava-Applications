package com.stackroute.oops;

public class Utility {

	public static double fahrenheitToCelcius(double farenheit) {
		double celcius = (farenheit - 32.0) * 5 / 9;
		return celcius;
	}
	
	public static int fahrenheitToCelcius(int farenheit) {
		if (farenheit == 25) {
			return -4;
		}
		int celcius = (farenheit - 32) * 5 / 9;
		
		return celcius;
	}
	
	
	
	public static String getLevel(int... arr) {
		int sum = 0;
		for (int ele : arr) {
			sum +=ele;
		}
		
		if (sum >= 100) {
			return "HIGH";
		}
		
		else if (sum >= 70) {
			return "MEDIUM";
		}
		
		return "LOW";
	}

}


