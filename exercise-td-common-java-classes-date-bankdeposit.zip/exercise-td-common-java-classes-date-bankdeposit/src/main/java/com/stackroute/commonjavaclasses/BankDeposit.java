package com.stackroute.commonjavaclasses;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class BankDeposit {

    public String getMaturityDate(String investmentDate, Period duration) {
        if (investmentDate == null || duration == null) {
            return "Give proper input not null";
        }
        if (investmentDate.length() == 0) {
            return "Give proper input not empty investment date";
        }

        String[] dateList = investmentDate.split("/");
        int year = Integer.parseInt(dateList[2]);
        int month = Integer.parseInt(dateList[1]);
        int day = Integer.parseInt(dateList[0]);

        if (year < 0 || month < 0 || day < 0) {
            return "Give proper duration not negative value";
        }
        if ((duration.getYears() < 0) || (duration.getMonths() < 0) || (duration.getDays() < 0)) {
            return "Give proper duration not negative value";
        }
        LocalDate investDate = LocalDate.of(year, month, day);
        LocalDate ans = investDate.plus(duration);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        return ans.format(myFormatObj);

    }

    public String getInvestmentDuration(String investmentDate, String maturityDate) {
        if (investmentDate == null || maturityDate == null) {
            return "Give proper input not null";
        }
        if (investmentDate.length() == 0 || maturityDate.length() == 0) {
            return "Give proper input not empty value";
        }
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        LocalDate investDate = LocalDate.parse(investmentDate, myFormatObj);
        LocalDate maturityDate2 = LocalDate.parse(maturityDate, myFormatObj);


        if (maturityDate2.getYear() < investDate.getYear()) {
            return "Give proper maturity date greater than investment date";
        }
        Period ans = Period.of(maturityDate2.getYear(), maturityDate2.getMonthValue(), maturityDate2.getDayOfMonth()).minus(Period.of(investDate.getYear(), investDate.getMonthValue(), investDate.getDayOfMonth()));
        Period output = Period.of(0, 0, 0);
        System.out.println(output.toString());
        return ans.toString();

    }
}
