package com.stackroute.strings;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MaxCharacterTests {
	private MaxCharacter maxcharacter;
	@BeforeEach
	public void setup() {
		maxcharacter = new MaxCharacter();
		
	}
	@AfterEach
    public void tearDown() {
        maxcharacter = null;
    }

	@Test
	void findMaxCharacterCountForAlphabeticString() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("Java");
		assertEquals('a',result);
	}
	@Test
	void findMaxCharacterCountForAlphabeticUpper() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("JAVA");
		assertEquals('A',result);
	}
	@Test
	void findMaxCharacterCountForAlphabetic2() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("JAVAPROGRAM");
		assertEquals('A',result);
	}
	@Test
	void findMaxCharacterCountForSpecialCharactersString() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("#$%@@");
		assertEquals('@',result);
	}
	@Test
	void findMaxCharacterCountForSpecialCharacter1() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("#$%@@###");
		assertEquals('#',result);
	}
	@Test
	void findMaxCharacterCountForSpecialCharacter2() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("#$%@@%%%%");
		assertEquals('%',result);
	}
	@Test
	void findMaxCharacterCountForDigitsString() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("11010234");
		assertEquals('1',result);
	}
	@Test
	void findMaxCharacterCountForDigits1() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("110102342222222");
		assertEquals('2',result);
	}
	@Test
	void findMaxCharacterCountForDigits2() throws IOException{
		char result = maxcharacter.findMaxCharacterCount("110102340000");
		assertEquals('0',result);
	}



}
