package com.stackroute.collections;

import java.util.Comparator;

public class PlayerNameComparator implements Comparator<Player> {
	public int compare(Player p1, Player p2) {
		String s1=p1.getPlayerName();
		String s2=p2.getPlayerName();
		return s1.compareTo(s2);
	}
}
