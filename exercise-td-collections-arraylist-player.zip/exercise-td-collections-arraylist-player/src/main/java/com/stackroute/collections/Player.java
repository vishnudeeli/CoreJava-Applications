package com.stackroute.collections;

public class Player {
	private int playerId;
	private String playerName;
	private int playerScore;
	private String match;
	
	
	public Player(int playerId, String playerName, int playerScore, String match) {
		// TODO Auto-generated constructor stub
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerScore = playerScore;
		this.match = match;
	}
	
	public void setPlayerId(int playerId) {
		 this.playerId = playerId;
	}
	
	public int getPlayerId() {
		return playerId;
	}
	
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	
	public String getPlayerName() {
		return playerName;
	}
	
	public void setPlayerScore(int playerScore) {
		this.playerScore = playerScore;
	}
	
	public int getPlayerScore() {
		return playerScore;
	}
	
	public void setPlayerMatch(String match) {
		this.match = match;
	}
	
	public String getPlayerMatch() {
		return match;
	}
	
	public String toString() {
		String str = "playerId=1, playerName=Sachin Tendulkar, playerScore=49" + getPlayerId() + ", playerName=" + getPlayerName() + ", playerScore=" + getPlayerScore() + "playerMatch=" + getPlayerMatch();
		return str;
	}

}
