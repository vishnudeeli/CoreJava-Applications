package com.stackroute.collections;

import java.util.Comparator;

public class PlayerScoreComparator implements Comparator<Player> {
	public int compare(Player p1, Player p2) {
		int s1=p1.getPlayerScore();
		int s2=p2.getPlayerScore();
		if(s1==s2) {
			int id1=p1.getPlayerId();
			int id2=p2.getPlayerId();
			return id1-id2;
		}
		else {
			return s2-s1;
		}
	}
}
