package com.stackroute.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PlayerListService {
	public List<Player> addedPlayerList=new ArrayList<Player>();
	public void addPlayersToList(Player player) {
		addedPlayerList.add(player);
	}
	public List<Player> getPlayerList(){
		return addedPlayerList;
	}
	public List<Player> getPlayerListSortedByNameIgnoringCaseInAscendingOrder(){
			Collections.sort(addedPlayerList,new PlayerNameComparator());
			return addedPlayerList;
		
	}
	public List<Player> getPlayerListSortedByScoreInDescendingOrder(){
		Collections.sort(addedPlayerList,new PlayerScoreComparator());
		return addedPlayerList;
	}
	public List<Player> getPlayerListGreaterThanFiftySortedByScoreInDescendingOrder(){
		List<Player> new_list=new ArrayList<Player>();
		for(Player player:addedPlayerList) {
			if(player.getPlayerScore()>50) {
				new_list.add(player);
			}else {
				continue;
			}
		}
		if(new_list.size()>0) {
			Collections.sort(new_list, new PlayerScoreComparator());
			return new_list;
		}
		else {
			return new_list;
		}
		
	}
	public List<Player> getPlayerListPlayedInSameMatchSortedByNameInAscendingOrder(String match){
		List<Player> new_list= new ArrayList<Player>();
		for(Player player:addedPlayerList) {
			if((player.getPlayerMatch()).equals(match)) {
				new_list.add(player);
			}
		}
		Collections.sort(new_list, new PlayerNameComparator());
		return new_list;
		
	}
}
