package com.stackroute.exercises;

import java.util.ArrayList;
import java.util.List;

//class should have a generic list variable
public class Stringify {

    public static void main(String[] args) {
        Stringify a = new Stringify();
        String ans = a.inputValidator(new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
        String ans1 = a.inputValidator(new String[]{"Hi", "my", "name", "is", "Joel"});
        System.out.println(ans);
        System.out.println(ans1);
    }

    //write here logic to validate the generic input
    public <E> String inputValidator(E[] obj) {

        if (obj == null) {
            return "Given value is null";
        } else {
            for (var a : obj) {
                if (a == null) {
                    return "Given array contains a null value";
                }
            }
        }
        List<String> ans = new ArrayList<>();
        for (var a: obj) {
            ans.add( String.valueOf(a));
        }
        if(ans.size() == 1){
            if(ans.get(0).equals("")){
                return "The given array contains one value which is empty or blank space";
            }
        }
//        System.out.println(ans);
        return this.stringGenerator(ans);
    }

    //write here logic to convert array list to string
    public String stringGenerator(List<String> obj) {
        return String.join(" ", obj);
    }

}
