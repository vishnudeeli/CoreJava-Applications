package com.stackroute.studentmanagement.errorhandler;

public class StudentNotFoundException extends Exception{
    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
