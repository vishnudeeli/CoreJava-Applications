package com.stackroute.studentmanagement.errorhandler;

public class StudentAlreadyExistsException extends Exception{
    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
